Complete Multi-Choice Box Editor is a simple tool for editing the Multi-Choice Boxes in Pokemon Games.

It handles all the repointing for you, you never have to type in an offset... ever. If you do however, it will put the data where you tell it... it assumes you mean to put it there even if its overwriting stuff.

You can repoint the whole table if you need to add more, but this must be done before editing any boxes. You can increase or decrease the number of choices in any box but this must be done before editing any choices...

currently only supports BPRE 1.0

1.1 Added BPEE support